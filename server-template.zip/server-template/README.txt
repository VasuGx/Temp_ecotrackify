Request flow:  routes -> service -> model -> utilities/connection.js -> MongoDB
- routes/     : URL + HTTP status only
- service/    : business logic + Validator calls
- model/      : DB commands only (find, save, update, aggregate)
- schemas/    : Mongoose schemas (used by connection.js)
- validators/ : Validator.js
- middleware/ : authMiddleware.js, roleMiddleware.js, errorHandler.js (team lead writes these)
