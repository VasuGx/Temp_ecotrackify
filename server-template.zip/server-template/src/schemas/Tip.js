const mongoose = require("mongoose");

const tipSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    tip: { type: String, required: [true, "Tip is required"], trim: true, maxlength: 500 },
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  },
  { timestamps: true }
);

tipSchema.index({ tip: "text" }); // for search (US4)

module.exports = mongoose.model("Tip", tipSchema);
