const mongoose = require("mongoose");

const goalSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    goal: { type: String, required: [true, "Goal is required"], trim: true },
    category: { type: String, enum: ["energy", "waste", "transport", "other"], default: "other" },
    // target = % reduction; max 100 blocks unrealistic goals (US3)
    target: {
      type: Number,
      required: true,
      min: [1, "Target must be at least 1%"],
      max: [100, "Target cannot exceed 100%"],
    },
    progress: { type: Number, default: 0, min: 0, max: 100 },
    status: { type: String, enum: ["active", "achieved"], default: "active" },
  },
  { timestamps: true }
);

goalSchema.pre("save", function (next) {
  if (this.progress >= this.target) this.status = "achieved";
  next();
});

module.exports = mongoose.model("Goal", goalSchema);
