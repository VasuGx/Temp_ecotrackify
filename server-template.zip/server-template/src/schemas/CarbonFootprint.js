const mongoose = require("mongoose");

const carbonFootprintSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    transportation: { type: Number, required: true, min: [0, "Value cannot be negative"] },
    energyConsumption: { type: Number, required: true, min: [0, "Value cannot be negative"] },
    wasteDisposal: { type: Number, required: true, min: [0, "Value cannot be negative"] },
    total: { type: Number, default: 0 },
    date: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Simple calculation - adjust the factors if your trainer gives a formula
const FACTORS = { transportation: 0.21, energyConsumption: 0.5, wasteDisposal: 0.1 };

carbonFootprintSchema.pre("save", function (next) {
  this.total = +(
    this.transportation * FACTORS.transportation +
    this.energyConsumption * FACTORS.energyConsumption +
    this.wasteDisposal * FACTORS.wasteDisposal
  ).toFixed(2);
  next();
});

module.exports = mongoose.model("CarbonFootprint", carbonFootprintSchema);
