// SERVICE LAYER
const Validator = require("../validators/Validator");
const notificationModel = require("../model/notificationModel");
const userModel = require("../model/userModel");
let notificationService = {};

// INPUT : userId
// OUTPUT: { notificationsEnabled: true/false }
notificationService.getSettings = async (userId) => {};

// INPUT : userId, body { notificationsEnabled: boolean }
// DOES  : validate -> update user
// OUTPUT: { message: "Notification settings updated" }
notificationService.updateSettings = async (userId, body) => {};

// INPUT : userId
// OUTPUT: { notifications: [ { id, message, read, createdAt } ] }
notificationService.getNotifications = async (userId) => {};

// INPUT : userId, notificationId
// OUTPUT: { message: "Marked as read" }
notificationService.markAsRead = async (userId, notificationId) => {};

// INTERNAL (called by goalService etc., NOT by a route)
// INPUT : userId, message
// DOES  : skip if user turned notifications off OR same message was sent recently (no spam)
// OUTPUT: created notification, or null if skipped
notificationService.notifyUser = async (userId, message) => {};

module.exports = notificationService;
