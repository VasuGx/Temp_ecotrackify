// SERVICE LAYER (US5) - combines data from models into one response
const carbonFootprintModel = require("../model/carbonFootprintModel");
const goalModel = require("../model/goalModel");
let dashboardService = {};

// INPUT : userId, query { from?, to? }
// DOES  : gather totals + history + goals into ONE response so the frontend makes a single call
// OUTPUT: {
//   footprint: { total, bySource: { transportation, energyConsumption, wasteDisposal } },
//   trend:     [ { date, total } ],            // for line chart
//   goals:     [ { goal, target, progress } ], // for progress bars
//   achievements: [ goal names achieved ]
// }
dashboardService.getDashboardSummary = async (userId, query) => {};

module.exports = dashboardService;
