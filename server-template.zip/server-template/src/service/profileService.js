// SERVICE LAYER
const Validator = require("../validators/Validator");
const userModel = require("../model/userModel");
const carbonFootprintModel = require("../model/carbonFootprintModel");
const goalModel = require("../model/goalModel");
let profileService = {};

// INPUT : userId (from JWT)
// DOES  : load user + their carbon total + their goals
// OUTPUT: { email, totalFootprint, sustainabilityGoals: [{ goal, progress }] }
profileService.getProfile = async (userId) => {};

// INPUT : userId, body { name?, email? }
// DOES  : validate only the fields sent -> make sure new email is not taken -> update
// OUTPUT: { message: "Profile updated successfully" }
// ERRORS: 400 invalid / email in use
profileService.updateProfile = async (userId, body) => {};

module.exports = profileService;
