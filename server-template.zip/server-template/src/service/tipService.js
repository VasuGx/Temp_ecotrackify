// SERVICE LAYER
const Validator = require("../validators/Validator");
const tipModel = require("../model/tipModel");
let tipService = {};

// INPUT : query { search?, page?, limit? }
// DOES  : validate search -> fetch tips (empty result is NOT an error)
// OUTPUT: { practices: [ { id, tip, likes (count), createdAt } ] }
tipService.getTips = async (query) => {};

// INPUT : userId, body { tip }
// DOES  : validate tip (length + inappropriate content) -> save
// OUTPUT: { message: "Tip shared successfully" }   (route sends 201)
// ERRORS: 400 invalid / inappropriate
tipService.shareTip = async (userId, body) => {};

// INPUT : userId, tipId
// DOES  : validate id -> add like (no duplicate likes)
// OUTPUT: { message: "Tip liked", likes: <count> }
// ERRORS: 404 tip not found
tipService.likeTip = async (userId, tipId) => {};

// INPUT : userId, tipId
// OUTPUT: { message: "Tip unliked", likes: <count> }
tipService.unlikeTip = async (userId, tipId) => {};

module.exports = tipService;
