// SERVICE LAYER (US7)
const Validator = require("../validators/Validator");
const userModel = require("../model/userModel");
const carbonFootprintModel = require("../model/carbonFootprintModel");
const goalModel = require("../model/goalModel");
let businessService = {};

// INPUT : businessId, body { email }
// DOES  : validate -> find employee by email -> link to business (employee must still approve sharing)
// OUTPUT: { message: "Employee added" }
// ERRORS: 404 employee not found
businessService.addEmployee = async (businessId, body) => {};

// INPUT : businessId
// OUTPUT: { employees: [ { id, name, email, sharing: true/false } ] }
businessService.getEmployees = async (businessId) => {};

// INPUT : businessId, employeeId
// DOES  : if employee.shareDataWithEmployer is false -> 403 (no data without permission)
// OUTPUT: { employee: {id,name}, totalFootprint, goals: [ { goal, progress } ] }
businessService.getEmployeeProgress = async (businessId, employeeId) => {};

// INPUT : businessId
// DOES  : aggregate ONLY employees who consented
// OUTPUT: { employeeCount, averageFootprint, goalsAchieved, goalsActive }
businessService.getCompanyProgress = async (businessId) => {};

// INPUT : userId (employee), body { shareDataWithEmployer: boolean }
// OUTPUT: { message: "Data sharing updated" }
businessService.setDataSharing = async (userId, body) => {};

// INPUT : none
// OUTPUT: { resources: [ { title, description, link } ] }  (static list of sustainability resources)
businessService.getResources = async () => {};

module.exports = businessService;
