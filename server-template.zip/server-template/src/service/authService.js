// SERVICE LAYER: business logic. Calls Validator + model files. No req/res here.
const Validator = require("../validators/Validator");
const userModel = require("../model/userModel");
let authService = {};

// INPUT : body { name?, email, password, role? }
// DOES  : validate -> check email not already used -> create user -> send confirmation email
// OUTPUT: { message: "User created successfully" }   (route sends 201)
// ERRORS: 400 invalid body / email already exists
authService.registerUser = async (body) => {};

// INPUT : body { email, password }
// DOES  : validate -> find user -> compare password -> sign JWT
// OUTPUT: { token: "<JWT_token>" }
// ERRORS: 401 "Invalid credentials"
authService.loginUser = async (body) => {};

// INPUT : email
// DOES  : find user -> create random token -> store HASHED token + expiry (e.g. 15 min) -> email reset link
// OUTPUT: { message: "Password reset email sent" }
// ERRORS: 404 "User not found"
authService.forgotPassword = async (email) => {};

// INPUT : token (from URL), body { password }
// DOES  : validate password -> hash token, find valid user -> update password -> clear token
// OUTPUT: { message: "Password reset successful" }
// ERRORS: 400 "Invalid token"
authService.resetPassword = async (token, body) => {};

// INPUT : userId
// DOES  : (used by auth middleware) load user from the JWT payload
// OUTPUT: user object without password, or throws 401
authService.getUserFromToken = async (userId) => {};

module.exports = authService;
