// SERVICE LAYER
const Validator = require("../validators/Validator");
const goalModel = require("../model/goalModel");
let goalService = {};

// INPUT : userId, body { goals: [ { goal, target, category? } ] }  (API doc sends an array)
// DOES  : validate each goal (target 1-100) -> create all
// OUTPUT: { message: "Sustainability goals set successfully" }
// ERRORS: 400 invalid / unrealistic goal
goalService.setGoals = async (userId, body) => {};

// INPUT : userId
// OUTPUT: { goals: [ { id, goal, target, progress, status } ] }
goalService.getGoals = async (userId) => {};

// INPUT : userId, goalId, body { goal?, target?, progress? }
// DOES  : validate id + fields -> update only if goal belongs to user
// OUTPUT: { message: "Sustainability goals updated successfully" }
// ERRORS: 404 goal not found
goalService.updateGoal = async (userId, goalId, body) => {};

// INPUT : userId, goalId
// DOES  : delete goal (must not crash if already deleted)
// OUTPUT: { message: "Goal deleted successfully" }
// ERRORS: 404 goal not found
goalService.deleteGoal = async (userId, goalId) => {};

// INPUT : userId
// DOES  : recompute progress of every active goal from carbon history;
//         when a goal is achieved -> call notificationService.notifyUser(...)
// OUTPUT: array of goals that were newly achieved
goalService.refreshGoalProgress = async (userId) => {};

module.exports = goalService;
