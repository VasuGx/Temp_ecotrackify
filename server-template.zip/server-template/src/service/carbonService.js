// SERVICE LAYER
const Validator = require("../validators/Validator");
const carbonFootprintModel = require("../model/carbonFootprintModel");
let carbonService = {};

// INPUT : userId, body { transportation, energyConsumption, wasteDisposal }
// DOES  : validate (no negatives / non-numbers) -> save entry -> then call goalService.refreshGoalProgress(userId)
// OUTPUT: { message: "Carbon footprint tracked successfully", total }
// ERRORS: 400 bad input
carbonService.trackCarbonFootprint = async (userId, body) => {};

// INPUT : userId, query { from?, to? }
// DOES  : validate dates -> fetch entries
// OUTPUT: { entries: [ { date, transportation, energyConsumption, wasteDisposal, total } ] }
carbonService.getCarbonHistory = async (userId, query) => {};

// INPUT : userId, query { from?, to? }
// DOES  : sum per source + total + simple reduction tips for the biggest source (US2: tips per source)
// OUTPUT: { transportation, energyConsumption, wasteDisposal, total, tips: [string] }
carbonService.getCarbonSummary = async (userId, query) => {};

module.exports = carbonService;
