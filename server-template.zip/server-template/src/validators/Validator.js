const mongoose = require("mongoose");

let Validator = {};

// Helper: every validator throws an error with status 400 (same style as training code)
const fail = (message) => {
  let err = new Error(message);
  err.status = 400;
  throw err;
};

/* ---------- AUTH (US1) ---------- */

Validator.validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (typeof email !== "string" || !regex.test(email.trim())) {
    fail("Invalid email address");
  }
  return true;
};

Validator.validatePassword = (password) => {
  if (typeof password !== "string" || password.length < 6) {
    fail("Password must be at least 6 characters");
  }
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    fail("Password must contain at least one letter and one number");
  }
  return true;
};

Validator.validateName = (name) => {
  if (typeof name !== "string" || name.trim().length < 2 || name.trim().length > 50) {
    fail("Name must be between 2 and 50 characters");
  }
  return true;
};

Validator.validateRole = (role) => {
  if (!["user", "business"].includes(role)) {
    fail("Role must be either 'user' or 'business'");
  }
  return true;
};

Validator.validateRegister = ({ name, email, password, role }) => {
  if (name !== undefined) Validator.validateName(name);
  Validator.validateEmail(email);
  Validator.validatePassword(password);
  if (role !== undefined) Validator.validateRole(role);
  return true;
};

Validator.validateLogin = ({ email, password }) => {
  Validator.validateEmail(email);
  if (!password) fail("Password is required");
  return true;
};

Validator.validateResetToken = (token) => {
  if (typeof token !== "string" || token.trim().length < 10) {
    fail("Invalid token");
  }
  return true;
};

/* ---------- COMMON ---------- */

Validator.validateObjectId = (id) => {
  if (!mongoose.Types.ObjectId.isValid(id)) fail("Invalid id");
  return true;
};

Validator.validateRequired = (value, fieldName) => {
  if (value === undefined || value === null || String(value).trim() === "") {
    fail(`${fieldName} is required`);
  }
  return true;
};

/* ---------- CARBON FOOTPRINT (US2) ---------- */

Validator.validateEmissionValue = (value, fieldName) => {
  if (typeof value !== "number" || Number.isNaN(value)) {
    fail(`${fieldName} must be a number`);
  }
  if (value < 0) fail(`${fieldName} cannot be negative`);
  if (value > 100000) fail(`${fieldName} is unrealistically high`);
  return true;
};

Validator.validateCarbonFootprint = ({ transportation, energyConsumption, wasteDisposal }) => {
  Validator.validateEmissionValue(transportation, "Transportation");
  Validator.validateEmissionValue(energyConsumption, "Energy consumption");
  Validator.validateEmissionValue(wasteDisposal, "Waste disposal");
  return true;
};

/* ---------- SUSTAINABILITY GOALS (US3) ---------- */

Validator.validateGoalText = (goal) => {
  if (typeof goal !== "string" || goal.trim().length < 3 || goal.trim().length > 200) {
    fail("Goal must be between 3 and 200 characters");
  }
  return true;
};

Validator.validateGoalTarget = (target) => {
  if (typeof target !== "number" || Number.isNaN(target)) fail("Target must be a number");
  if (target < 1 || target > 100) fail("Target must be between 1 and 100 (unrealistic goal)");
  return true;
};

Validator.validateProgress = (progress) => {
  if (typeof progress !== "number" || Number.isNaN(progress)) fail("Progress must be a number");
  if (progress < 0 || progress > 100) fail("Progress must be between 0 and 100");
  return true;
};

Validator.validateGoal = ({ goal, target }) => {
  Validator.validateGoalText(goal);
  Validator.validateGoalTarget(target);
  return true;
};

/* ---------- TIPS / COMMUNITY (US4) ---------- */

// Basic inappropriate-content filter - extend the list as needed
const BLOCKED_WORDS = ["spam", "abuse", "hate", "scam"];

Validator.validateTip = (tip) => {
  if (typeof tip !== "string" || tip.trim().length < 5) {
    fail("Tip must be at least 5 characters");
  }
  if (tip.length > 500) fail("Tip cannot exceed 500 characters");
  const lower = tip.toLowerCase();
  if (BLOCKED_WORDS.some((word) => lower.includes(word))) {
    fail("Tip contains inappropriate content");
  }
  return true;
};

Validator.validateSearchQuery = (query) => {
  if (query !== undefined && (typeof query !== "string" || query.length > 100)) {
    fail("Invalid search query");
  }
  return true;
};

/* ---------- NOTIFICATIONS (US6) ---------- */

Validator.validateNotificationSettings = ({ notificationsEnabled }) => {
  if (typeof notificationsEnabled !== "boolean") {
    fail("notificationsEnabled must be true or false");
  }
  return true;
};

/* ---------- BUSINESS (US7) ---------- */

Validator.validateEmployeeInvite = ({ email }) => {
  Validator.validateEmail(email);
  return true;
};

/* ---------- PAGINATION / DATES (optional, for dashboard) ---------- */

Validator.validateDateRange = (from, to) => {
  const f = new Date(from);
  const t = new Date(to);
  if (isNaN(f) || isNaN(t)) fail("Invalid date");
  if (f > t) fail("'from' date cannot be after 'to' date");
  return true;
};

module.exports = Validator;
