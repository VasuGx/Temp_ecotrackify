// MODEL LAYER: only database commands.
// Uses: connection.getNotificationCollection()
const connection = require("../utilities/connection");
let notificationModel = {};

// INPUT : { user, message }
// OUTPUT: saved notification
notificationModel.createNotification = async (obj) => {};

// INPUT : userId
// OUTPUT: array of notifications, newest first
notificationModel.getNotificationsByUser = async (userId) => {};

// INPUT : notificationId, userId
// OUTPUT: updated notification (read = true), or null
notificationModel.markAsRead = async (notificationId, userId) => {};

// INPUT : userId, message
// OUTPUT: the latest notification with the same message, or null
//         (used by the service to avoid sending duplicates / spamming)
notificationModel.findRecentDuplicate = async (userId, message) => {};

module.exports = notificationModel;
