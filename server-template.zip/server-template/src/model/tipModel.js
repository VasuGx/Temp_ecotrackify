// MODEL LAYER: only database commands.
// Uses: connection.getTipCollection()
const connection = require("../utilities/connection");
let tipModel = {};

// INPUT : tipObj { user, tip }
// OUTPUT: saved tip document
tipModel.createTip = async (tipObj) => {};

// INPUT : { search?, page, limit }
// OUTPUT: array of tips (text search if `search` given), newest first
tipModel.getTips = async (query) => {};

// INPUT : tipId
// OUTPUT: tip document, or null
tipModel.getTipById = async (tipId) => {};

// INPUT : tipId, userId
// OUTPUT: updated tip (userId added to likes, no duplicates)
tipModel.addLike = async (tipId, userId) => {};

// INPUT : tipId, userId
// OUTPUT: updated tip (userId removed from likes)
tipModel.removeLike = async (tipId, userId) => {};

module.exports = tipModel;
