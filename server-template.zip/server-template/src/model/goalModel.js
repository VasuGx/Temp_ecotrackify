// MODEL LAYER: only database commands.
// Uses: connection.getGoalCollection()
const connection = require("../utilities/connection");
let goalModel = {};

// INPUT : goalObj { user, goal, category, target }
// OUTPUT: saved goal document
goalModel.createGoal = async (goalObj) => {};

// INPUT : userId
// OUTPUT: array of all goals of this user
goalModel.getGoalsByUser = async (userId) => {};

// INPUT : goalId, userId
// OUTPUT: goal document, or null (also null if it belongs to another user)
goalModel.getGoalById = async (goalId, userId) => {};

// INPUT : goalId, userId, updates { goal?, target?, progress? }
// OUTPUT: updated goal, or null if not found
goalModel.updateGoal = async (goalId, userId, updates) => {};

// INPUT : goalId, userId
// OUTPUT: true if deleted, false if not found
goalModel.deleteGoal = async (goalId, userId) => {};

module.exports = goalModel;
