// MODEL LAYER: only database commands. No business rules here.
// Uses: connection.getUserCollection()
const connection = require("../utilities/connection");
let userModel = {};

// INPUT : userObj { name, email, password, role }
// OUTPUT: saved user document (password is hashed by the schema)
userModel.createUser = async (userObj) => {};

// INPUT : email (string)
// OUTPUT: user document, or null if not found
userModel.findUserByEmail = async (email) => {};

// INPUT : userId (string)
// OUTPUT: user document WITHOUT password/reset fields, or null
userModel.findUserById = async (userId) => {};

// INPUT : hashedToken (string)
// OUTPUT: user whose resetPasswordToken matches AND is not expired, or null
userModel.findUserByResetToken = async (hashedToken) => {};

// INPUT : userId, token (hashed string), expireDate (Date)
// OUTPUT: true when saved
userModel.saveResetToken = async (userId, token, expireDate) => {};

// INPUT : userId, newPassword (plain; schema hashes it)
// OUTPUT: true when saved (also clears reset token + expiry)
userModel.updatePassword = async (userId, newPassword) => {};

// INPUT : userId, updates { name?, email?, notificationsEnabled?, shareDataWithEmployer? }
// OUTPUT: updated user document (without password)
userModel.updateUserById = async (userId, updates) => {};

// INPUT : businessId
// OUTPUT: array of employee users whose employer == businessId
userModel.findEmployeesByEmployer = async (businessId) => {};

// INPUT : employeeEmail, businessId
// OUTPUT: employee document after setting employer = businessId, or null if no such user
userModel.linkEmployeeToBusiness = async (employeeEmail, businessId) => {};

module.exports = userModel;
