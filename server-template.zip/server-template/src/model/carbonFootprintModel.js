// MODEL LAYER: only database commands.
// Uses: connection.getCarbonFootprintCollection()
const connection = require("../utilities/connection");
let carbonFootprintModel = {};

// INPUT : entry { user, transportation, energyConsumption, wasteDisposal }
// OUTPUT: saved entry (with calculated total)
carbonFootprintModel.addEntry = async (entry) => {};

// INPUT : userId, { from?, to? } date range
// OUTPUT: array of entries, newest first
carbonFootprintModel.getEntriesByUser = async (userId, range) => {};

// INPUT : userId, { from?, to? }
// OUTPUT: { transportation, energyConsumption, wasteDisposal, total } (sums, aggregation query)
carbonFootprintModel.getTotalsByUser = async (userId, range) => {};

// INPUT : userIds (array), { from?, to? }
// OUTPUT: array of { user, total } - used for business/company view
carbonFootprintModel.getTotalsForUsers = async (userIds, range) => {};

module.exports = carbonFootprintModel;
