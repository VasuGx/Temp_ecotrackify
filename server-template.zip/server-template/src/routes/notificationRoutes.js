const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const notificationService = require("../service/notificationService");

// GET /api/v1/notifications/settings        (protected) -> 200 { notificationsEnabled }
router.get("/settings", authMiddleware, async (req, res, next) => {});

// PUT /api/v1/notifications/settings        (protected) body: { notificationsEnabled } -> 200 { message }
router.put("/settings", authMiddleware, async (req, res, next) => {});

// GET /api/v1/notifications                 (protected) -> 200 { notifications }
router.get("/", authMiddleware, async (req, res, next) => {});

// PUT /api/v1/notifications/:id/read        (protected) -> 200 { message }
router.put("/:id/read", authMiddleware, async (req, res, next) => {});

module.exports = router;
