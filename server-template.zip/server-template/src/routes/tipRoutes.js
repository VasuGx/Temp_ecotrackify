const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const tipService = require("../service/tipService");

// GET  /api/v1/eco-friendly-practices?search=&page=&limit=   (protected) -> 200 { practices }
router.get("/", authMiddleware, async (req, res, next) => {});

// POST /api/v1/eco-friendly-practices       (protected) body: { tip } -> 201 { message }
router.post("/", authMiddleware, async (req, res, next) => {});

// POST   /api/v1/eco-friendly-practices/:id/like   (protected) -> 200 { message, likes }
router.post("/:id/like", authMiddleware, async (req, res, next) => {});

// DELETE /api/v1/eco-friendly-practices/:id/like   (protected) -> 200 { message, likes }
router.delete("/:id/like", authMiddleware, async (req, res, next) => {});

module.exports = router;
