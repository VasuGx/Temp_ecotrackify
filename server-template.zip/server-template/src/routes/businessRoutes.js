const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware"); // roleMiddleware("business")
const businessService = require("../service/businessService");

// POST /api/v1/business/employees          (business) body: { email } -> 201 { message }
router.post("/employees", authMiddleware, roleMiddleware("business"), async (req, res, next) => {});

// GET  /api/v1/business/employees          (business) -> 200 { employees }
router.get("/employees", authMiddleware, roleMiddleware("business"), async (req, res, next) => {});

// GET  /api/v1/business/employees/:id/progress   (business) -> 200 { employee, totalFootprint, goals } | 403 if no consent
router.get("/employees/:id/progress", authMiddleware, roleMiddleware("business"), async (req, res, next) => {});

// GET  /api/v1/business/progress           (business) -> 200 { employeeCount, averageFootprint, ... }
router.get("/progress", authMiddleware, roleMiddleware("business"), async (req, res, next) => {});

// GET  /api/v1/business/resources          (business) -> 200 { resources }
router.get("/resources", authMiddleware, roleMiddleware("business"), async (req, res, next) => {});

// PUT  /api/v1/business/data-sharing       (any logged-in employee) body: { shareDataWithEmployer } -> 200 { message }
router.put("/data-sharing", authMiddleware, async (req, res, next) => {});

module.exports = router;
