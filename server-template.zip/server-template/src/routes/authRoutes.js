// ROUTE LAYER: only maps URL -> service. Send status code + JSON. Errors go to next(err).
const express = require("express");
const router = express.Router();
const authService = require("../service/authService");

// POST /api/v1/auth/register   body: { name?, email, password }   -> 201 { message }
router.post("/register", async (req, res, next) => {});

// POST /api/v1/auth/login      body: { email, password }          -> 200 { token }
router.post("/login", async (req, res, next) => {});

// POST /api/v1/auth/forgot-password   body: { email }             -> 200 { message }
router.post("/forgot-password", async (req, res, next) => {});

// POST /api/v1/auth/reset-password/:token   body: { password }    -> 200 { message }
router.post("/reset-password/:token", async (req, res, next) => {});

module.exports = router;
