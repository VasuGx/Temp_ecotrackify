const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware"); // verifies JWT, sets req.user
const profileService = require("../service/profileService");

// GET /api/v1/profile    (protected)                 -> 200 { email, totalFootprint, sustainabilityGoals }
router.get("/", authMiddleware, async (req, res, next) => {});

// PUT /api/v1/profile    (protected) body: { name?, email? } -> 200 { message }
router.put("/", authMiddleware, async (req, res, next) => {});

module.exports = router;
