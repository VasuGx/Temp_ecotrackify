const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const goalService = require("../service/goalService");

// POST   /api/v1/sustainability-goals        (protected) body: { goals: [...] } -> 200 { message }
router.post("/", authMiddleware, async (req, res, next) => {});

// GET    /api/v1/sustainability-goals        (protected) -> 200 { goals }
router.get("/", authMiddleware, async (req, res, next) => {});

// PUT    /api/v1/sustainability-goals/:id    (protected) body: { goal?, target?, progress? } -> 200 { message }
router.put("/:id", authMiddleware, async (req, res, next) => {});

// DELETE /api/v1/sustainability-goals/:id    (protected) -> 200 { message }
router.delete("/:id", authMiddleware, async (req, res, next) => {});

module.exports = router;
