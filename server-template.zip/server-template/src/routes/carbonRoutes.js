const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const carbonService = require("../service/carbonService");

// POST /api/v1/carbon-footprint          (protected) body: { transportation, energyConsumption, wasteDisposal } -> 200 { message }
router.post("/", authMiddleware, async (req, res, next) => {});

// GET  /api/v1/carbon-footprint          (protected) query: from, to -> 200 { entries }
router.get("/", authMiddleware, async (req, res, next) => {});

// GET  /api/v1/carbon-footprint/summary  (protected) -> 200 { totals, tips }
router.get("/summary", authMiddleware, async (req, res, next) => {});

module.exports = router;
