const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const dashboardService = require("../service/dashboardService");

// GET /api/v1/dashboard/summary?from=&to=   (protected) -> 200 { footprint, trend, goals, achievements }
router.get("/summary", authMiddleware, async (req, res, next) => {});

module.exports = router;
