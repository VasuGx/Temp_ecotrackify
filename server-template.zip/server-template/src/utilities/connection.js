// Connects to MongoDB (URL from .env) and hands out models.
// Only files in /model should require this file.
const Mongoose = require("mongoose");

const User = require("../schemas/User");
const CarbonFootprint = require("../schemas/CarbonFootprint");
const Goal = require("../schemas/Goal");
const Tip = require("../schemas/Tip");
const Notification = require("../schemas/Notification");

const url = process.env.MONGO_URI; // e.g. mongodb+srv://... (Atlas) - set in .env

let connecting = null;
const connect = () => {
  if (!connecting) connecting = Mongoose.connect(url);
  return connecting;
};

let collection = {};

/* DO NOT CHANGE THE FUNCTION SIGNATURE OF ANY OF THE FUNCTIONS */
const getter = (modelObj) => async () => {
  try {
    await connect();
    return modelObj;
  } catch (error) {
    let err = new Error("Could not connect to Database");
    err.status = 500;
    throw err;
  }
};

collection.getUserCollection = getter(User);
collection.getCarbonFootprintCollection = getter(CarbonFootprint);
collection.getGoalCollection = getter(Goal);
collection.getTipCollection = getter(Tip);
collection.getNotificationCollection = getter(Notification);

module.exports = collection;
